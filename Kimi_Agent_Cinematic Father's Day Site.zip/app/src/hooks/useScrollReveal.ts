import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface ScrollRevealOptions {
  y?: number;
  x?: number;
  opacity?: number;
  scale?: number;
  duration?: number;
  stagger?: number;
  ease?: string;
  start?: string;
  childSelector?: string;
}

export default function useScrollReveal<T extends HTMLElement>(
  options: ScrollRevealOptions = {}
) {
  const ref = useRef<T>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      gsap.set(el.querySelectorAll(options.childSelector || '> *'), {
        opacity: 1,
        y: 0,
        x: 0,
        scale: 1,
      });
      return;
    }

    const targets = options.childSelector ? el.querySelectorAll(options.childSelector) : el;

    const ctx = gsap.context(() => {
      gsap.from(targets, {
        y: options.y ?? 40,
        x: options.x ?? 0,
        opacity: options.opacity ?? 0,
        scale: options.scale ?? 1,
        duration: options.duration ?? 0.7,
        stagger: options.stagger ?? 0.1,
        ease: options.ease ?? 'power2.out',
        scrollTrigger: {
          trigger: el,
          start: options.start ?? 'top 75%',
          toggleActions: 'play none none none',
        },
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return ref;
}
