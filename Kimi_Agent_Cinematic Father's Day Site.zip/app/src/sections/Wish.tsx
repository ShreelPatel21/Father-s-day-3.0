import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import AuroraStarfield from '../components/AuroraStarfield';

gsap.registerPlugin(ScrollTrigger);

export default function Wish() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      if (prefersReducedMotion) {
        gsap.set(el.querySelector('.wish-card'), { opacity: 1, scale: 1 });
        return;
      }

      gsap.from(el.querySelector('.wish-card'), {
        opacity: 0,
        scale: 0.9,
        duration: 1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 70%',
          toggleActions: 'play none none none',
        },
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="wishes"
      ref={sectionRef}
      className="relative w-full overflow-hidden"
      style={{ padding: 'clamp(120px, 18vh, 200px) 0' }}
      aria-label="The wish"
    >
      <AuroraStarfield
        starCount={200}
        particleCount={30}
        auroraOpacity={0.6}
        className="absolute inset-0"
      />

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-[2]">
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-golden"
            style={{
              width: `${2 + Math.random() * 3}px`,
              height: `${2 + Math.random() * 3}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.15 + Math.random() * 0.25,
              animation: `float ${3 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-[3] max-w-[800px] mx-auto px-6">
        <div className="wish-card glass-card-enhanced p-10 md:p-16 text-center relative overflow-hidden">
          {/* Animated border */}
          <div
            className="absolute inset-0 rounded-3xl pointer-events-none"
            style={{
              background: 'conic-gradient(from 0deg, transparent 0%, rgba(212,168,83,0.3) 25%, transparent 50%, rgba(212,168,83,0.3) 75%, transparent 100%)',
              animation: 'border-glow 8s linear infinite',
              mask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
              maskComposite: 'exclude',
              WebkitMaskComposite: 'xor',
              padding: '2px',
            }}
          />

          <span className="text-golden text-2xl block mb-8">&#10022;</span>

          <p
            className="font-display italic text-warm-cream leading-[1.7]"
            style={{ fontSize: 'clamp(1.25rem, 2.5vw, 1.8rem)' }}
          >
            Dad, your sacrifices became my strength, your guidance became my path, and your love
            became my greatest blessing.
          </p>

          <p className="font-display italic text-golden text-lg md:text-xl mt-10">
            Happy Father's Day 2026
          </p>
        </div>
      </div>
    </section>
  );
}
