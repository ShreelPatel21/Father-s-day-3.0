import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const cards = [
  {
    unsaid: 'My father never said he was tired.',
    reveal: 'But he still went to work every day.',
  },
  {
    unsaid: 'My father never said he was worried.',
    reveal: 'But he waited until I got home safely.',
  },
  {
    unsaid: 'My father never said he was struggling.',
    reveal: 'But he carried every burden for our family.',
  },
  {
    unsaid: 'My father never asked for recognition.',
    reveal: 'But he gave everything he had.',
  },
];

export default function FatherNeverSaid() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      el.querySelectorAll('.father-card').forEach((card) => {
        if (prefersReducedMotion) {
          gsap.set(card, { opacity: 1, y: 0 });
          gsap.set(card.querySelector('.reveal-line'), { opacity: 1 });
          return;
        }

        gsap.from(card, {
          opacity: 0,
          y: 40,
          duration: 0.7,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        });

        gsap.from(card.querySelector('.reveal-line'), {
          opacity: 0,
          duration: 0.5,
          delay: 0.4,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        });
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-[clamp(80px,12vh,140px)] bg-midnight"
      aria-label="The things my father never said"
    >
      {/* Subtle light rays */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-[0.03]">
        {Array.from({ length: 3 }).map((_, i) => (
          <div
            key={i}
            className="absolute h-full"
            style={{
              width: '2px',
              background: 'linear-gradient(to bottom, transparent, #D4A853, transparent)',
              left: `${20 + i * 30}%`,
              animation: `float ${6 + i * 2}s ease-in-out infinite`,
            }}
          />
        ))}
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-golden"
            style={{
              width: `${2 + Math.random() * 2}px`,
              height: `${2 + Math.random() * 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.1 + Math.random() * 0.2,
              animation: `float ${4 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-[800px] mx-auto px-6">
        <h2
          className="font-display italic text-golden text-center mb-2"
          style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}
        >
          The Things My Father Never Said
        </h2>
        <div
          className="w-[60%] max-w-[300px] h-px mx-auto mb-16"
          style={{ background: 'rgba(212, 168, 83, 0.4)' }}
        />

        <div className="space-y-6">
          {cards.map((card, i) => (
            <div
              key={i}
              className="father-card glass-card p-8 transition-all duration-500 hover:border-golden/40 hover:shadow-golden-glow"
            >
              <p className="font-display italic text-warm-cream text-lg md:text-xl mb-3">
                {card.unsaid}
              </p>
              <p className="reveal-line font-body font-light text-golden text-sm md:text-base">
                — {card.reveal}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
