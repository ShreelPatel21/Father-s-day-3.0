import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const stages = [
  {
    title: 'Learning to Walk',
    caption: 'You held my hands until I found my own feet.',
    position: 'left',
  },
  {
    title: 'First Day of School',
    caption: 'You stood at the gate longer than I knew.',
    position: 'right',
  },
  {
    title: 'Teenage Years',
    caption: 'We argued. You waited. You never stopped loving.',
    position: 'left',
  },
  {
    title: 'Graduation Day',
    caption: 'The proudest smile I have ever seen.',
    position: 'right',
  },
  {
    title: 'The Man I Am Becoming',
    caption: 'Every good thing in me started with you.',
    position: 'center',
  },
];

export default function Journey() {
  const sectionRef = useRef<HTMLElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    const line = lineRef.current;
    if (!el || !line) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      // Timeline line draw
      if (!prefersReducedMotion) {
        gsap.from(line, {
          scaleY: 0,
          transformOrigin: 'top',
          ease: 'none',
          scrollTrigger: {
            trigger: el,
            start: 'top 60%',
            end: 'bottom 80%',
            scrub: true,
          },
        });
      }

      // Stage cards
      el.querySelectorAll('.journey-card').forEach((card, i) => {
        const stage = stages[i];
        const fromX = stage.position === 'left' ? -30 : stage.position === 'right' ? 30 : 0;

        if (prefersReducedMotion) {
          gsap.set(card, { opacity: 1, x: 0, y: 0, scale: 1 });
          return;
        }

        gsap.from(card, {
          opacity: 0,
          y: 50,
          x: fromX,
          scale: 0.95,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        });
      });

      // Nodes
      el.querySelectorAll('.journey-node').forEach((node) => {
        if (prefersReducedMotion) {
          gsap.set(node, { opacity: 1, scale: 1 });
          return;
        }

        gsap.from(node, {
          opacity: 0,
          scale: 0,
          duration: 0.5,
          ease: 'back.out(2)',
          scrollTrigger: {
            trigger: node,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        });
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="journey"
      ref={sectionRef}
      className="relative w-full py-[clamp(80px,12vh,140px)] bg-midnight"
      aria-label="Our journey"
    >
      <div className="max-w-[1200px] mx-auto px-6">
        <h2
          className="font-display italic text-golden text-center mb-4"
          style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}
        >
          Our Journey Together
        </h2>
        <p className="font-body font-light text-light-slate text-center mb-16 tracking-wide">
          Every step of the way, you were there.
        </p>

        <div className="relative">
          {/* Timeline line - desktop centered, mobile left */}
          <div
            ref={lineRef}
            className="absolute md:left-1/2 md:-translate-x-1/2 left-5 top-0 bottom-0 w-0.5 md:w-0.5"
            style={{
              background: 'linear-gradient(to bottom, #D4A853, #C9A96E)',
              boxShadow: '0 0 10px rgba(212, 168, 83, 0.3)',
            }}
          />

          <div className="space-y-16 md:space-y-24">
            {stages.map((stage, i) => (
              <div
                key={i}
                className={`relative flex items-center ${
                  stage.position === 'center'
                    ? 'justify-center'
                    : stage.position === 'left'
                    ? 'md:flex-row-reverse'
                    : ''
                }`}
              >
                {/* Node */}
                <div
                  className="journey-node absolute md:left-1/2 md:-translate-x-1/2 left-5 -translate-x-1/2 w-3 h-3 rounded-full bg-golden z-10"
                  style={{
                    boxShadow: '0 0 0 4px rgba(212, 168, 83, 0.2), 0 0 10px rgba(212, 168, 83, 0.4)',
                  }}
                >
                  <span
                    className="absolute inset-0 rounded-full bg-golden"
                    style={{
                      animation: 'pulse-glow 2s ease-in-out infinite',
                    }}
                  />
                </div>

                {/* Card */}
                <div
                  className={`journey-card glass-card p-8 md:w-[45%] w-[calc(100%-3rem)] ml-12 md:ml-0 ${
                    stage.position === 'left'
                      ? 'md:mr-auto md:pr-12'
                      : stage.position === 'right'
                      ? 'md:ml-auto md:pl-12'
                      : 'md:max-w-md text-center'
                  }`}
                >
                  <h3 className="font-display italic text-golden text-xl mb-3">
                    {stage.title}
                  </h3>
                  <p className="font-body font-light text-light-slate text-sm leading-relaxed">
                    {stage.caption}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
