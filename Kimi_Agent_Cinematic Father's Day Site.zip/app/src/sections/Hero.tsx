import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import AuroraStarfield from '../components/AuroraStarfield';

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 300);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!loaded || !sectionRef.current) return;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ delay: 0.5 });

      tl.from('.hero-caption', {
        opacity: 0,
        y: 20,
        duration: 0.8,
        ease: 'power2.out',
      })
        .from(
          '.hero-title',
          {
            opacity: 0,
            y: 30,
            duration: 1,
            ease: 'power2.out',
          },
          '-=0.4'
        )
        .from(
          '.hero-subtitle',
          {
            opacity: 0,
            y: 20,
            duration: 0.8,
            ease: 'power2.out',
          },
          '-=0.5'
        )
        .from(
          '.hero-scroll',
          {
            opacity: 0,
            duration: 0.6,
            ease: 'power2.out',
          },
          '-=0.3'
        );

      // Silhouette entrance
      gsap.from('.hero-silhouette', {
        opacity: 0,
        y: 40,
        duration: 1.2,
        ease: 'power2.out',
        delay: 0.3,
      });
    }, sectionRef.current);

    return () => ctx.revert();
  }, [loaded]);

  // Click burst effect
  useEffect(() => {
    const canvas = sectionRef.current?.querySelector('canvas');
    if (!canvas) return;

    function handleClick(e: MouseEvent) {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      for (let i = 0; i < 12; i++) {
        const particle = document.createElement('div');
        particle.style.cssText = `
          position: absolute;
          width: 4px;
          height: 4px;
          background: #D4A853;
          border-radius: 50%;
          pointer-events: none;
          left: ${x}px;
          top: ${y}px;
          z-index: 10;
        `;
        sectionRef.current?.appendChild(particle);

        const angle = (Math.PI * 2 * i) / 12;
        const distance = 30 + Math.random() * 50;
        gsap.to(particle, {
          x: Math.cos(angle) * distance,
          y: Math.sin(angle) * distance,
          opacity: 0,
          scale: 0,
          duration: 0.8,
          ease: 'power2.out',
          onComplete: () => particle.remove(),
        });
      }
    }

    canvas.addEventListener('click', handleClick);
    return () => canvas.removeEventListener('click', handleClick);
  }, [loaded]);

  return (
    <section
      id="hero"
      ref={sectionRef}
      className="relative w-full overflow-hidden"
      style={{ height: '120vh' }}
      aria-label="Hero section"
    >
      <AuroraStarfield className="absolute inset-0" />

      {/* Silhouette */}
      <div
        className="hero-silhouette absolute bottom-0 left-0 md:left-[5%] z-[2] pointer-events-none"
        style={{ height: '70vh', opacity: 0.85 }}
      >
        <img
          src="/images/hero-boy.png"
          alt=""
          className="h-full w-auto object-contain"
          style={{ filter: 'brightness(0.4) contrast(1.2)' }}
        />
      </div>

      {/* Content */}
      <div className="relative z-[3] h-full flex flex-col items-center md:items-end justify-center px-6 md:px-[clamp(1.5rem,4vw,3rem)]">
        <div className="max-w-xl text-center md:text-right mt-[-10vh]">
          <p
            className="hero-caption font-body text-xs font-medium uppercase tracking-[0.2em] text-golden mb-6"
          >
            A Love Letter to My Father
          </p>
          <h1
            className="hero-title font-display font-bold text-white leading-[1.1] tracking-tight"
            style={{ fontSize: 'clamp(3rem, 7vw, 6rem)' }}
          >
            Happy Father's Day 2026
          </h1>
          <p
            className="hero-subtitle font-body font-light text-light-slate mt-6 leading-relaxed"
            style={{ fontSize: 'clamp(1rem, 1.5vw, 1.25rem)', letterSpacing: '0.02em' }}
          >
            The first hero of every son, the strongest hand that never lets go.
          </p>
        </div>

        {/* Scroll indicator */}
        <div className="hero-scroll absolute bottom-24 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="font-body text-xs text-light-slate/60 tracking-widest uppercase">
            Scroll to begin
          </span>
          <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            className="text-golden"
            style={{ animation: 'scroll-indicator 2s ease-in-out infinite' }}
          >
            <path
              d="M5 8L10 13L15 8"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>
    </section>
  );
}
