import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const flashes = [
  'Learning to walk...',
  'First day of school...',
  'Teenage arguments...',
  'Graduation day...',
  'Every sacrifice...',
];

const climaxLines = [
  'The older I become...',
  'The more I become like you...',
  'And that is the greatest compliment I could ever give.',
];

export default function Climax() {
  const sectionRef = useRef<HTMLElement>(null);
  const [showFlashes, setShowFlashes] = useState(false);
  const [showClimax, setShowClimax] = useState(false);
  const [currentFlash, setCurrentFlash] = useState(-1);
  const [currentClimaxLine, setCurrentClimaxLine] = useState(-1);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: el,
        start: 'top 50%',
        onEnter: () => {
          if (prefersReducedMotion) {
            setShowFlashes(true);
            setCurrentFlash(flashes.length - 1);
            setShowClimax(true);
            setCurrentClimaxLine(climaxLines.length - 1);
            return;
          }

          // Flash sequence
          setShowFlashes(true);
          let flashIdx = 0;
          const flashInterval = setInterval(() => {
            setCurrentFlash(flashIdx);
            flashIdx++;
            if (flashIdx >= flashes.length) {
              clearInterval(flashInterval);
              // Pause then show climax
              setTimeout(() => {
                setShowFlashes(false);
                setShowClimax(true);
                // Reveal climax lines one by one
                climaxLines.forEach((_, i) => {
                  setTimeout(() => {
                    setCurrentClimaxLine(i);
                  }, i * 600);
                });
              }, 1000);
            }
          }, 800);
        },
        once: true,
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full min-h-screen flex flex-col items-center justify-center py-[clamp(80px,12vh,140px)]"
      style={{ background: '#050810' }}
      aria-label="The realization"
    >
      {/* Intense floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 50 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-golden"
            style={{
              width: `${2 + Math.random() * 3}px`,
              height: `${2 + Math.random() * 3}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.15 + Math.random() * 0.3,
              animation: `float ${3 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      {/* Subtle radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(212,168,83,0.03) 0%, transparent 60%)',
        }}
      />

      <div className="relative z-10 max-w-[800px] mx-auto px-6 text-center min-h-[40vh] flex flex-col items-center justify-center">
        {/* Memory flashes */}
        {showFlashes && (
          <div className="relative h-20 flex items-center justify-center">
            {flashes.map((flash, i) => (
              <p
                key={i}
                className="font-display italic absolute transition-all duration-500"
                style={{
                  fontSize: 'clamp(1.5rem, 3vw, 2.5rem)',
                  opacity: currentFlash === i ? 1 : 0,
                  transform: currentFlash === i ? 'scale(1)' : 'scale(0.9)',
                  color: i % 2 === 0 ? '#D4A853' : '#F5E6C8',
                }}
              >
                {flash}
              </p>
            ))}
          </div>
        )}

        {/* Climax lines */}
        {showClimax && (
          <div className="space-y-6 mt-8">
            {climaxLines.map((line, i) => (
              <p
                key={i}
                className="font-display italic leading-[1.5] transition-all duration-700"
                style={{
                  fontSize: 'clamp(1.5rem, 3.5vw, 2.5rem)',
                  opacity: currentClimaxLine >= i ? 1 : 0,
                  transform: currentClimaxLine >= i ? 'translateY(0)' : 'translateY(20px)',
                  color: i === climaxLines.length - 1 ? '#D4A853' : '#F5E6C8',
                }}
              >
                {line}
              </p>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
