import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const letterText = `Dear Dad,

I know I don't always say what I feel.

We don't talk about emotions often.

But every success of mine carries your sacrifices.

Every dream I chase is possible because you believed in me first.

If I become a good man someday, it will be because I had a great father.

Happy Father's Day 2026.`;

export default function Letter() {
  const sectionRef = useRef<HTMLElement>(null);
  const [displayedText, setDisplayedText] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const [hasTriggered, setHasTriggered] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: el,
        start: 'top 60%',
        onEnter: () => {
          if (!hasTriggered) {
            setHasTriggered(true);
          }
        },
      });
    }, el);

    return () => ctx.revert();
  }, [hasTriggered]);

  useEffect(() => {
    if (!hasTriggered) return;

    let index = 0;
    intervalRef.current = setInterval(() => {
      if (index < letterText.length) {
        setDisplayedText(letterText.slice(0, index + 1));
        index++;
      } else {
        if (intervalRef.current) clearInterval(intervalRef.current);
        setIsComplete(true);
      }
    }, 40);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [hasTriggered]);

  return (
    <section
      id="letter"
      ref={sectionRef}
      className="relative w-full py-[clamp(80px,12vh,140px)] bg-midnight"
      aria-label="Letter to Dad"
      aria-live="polite"
    >
      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-golden"
            style={{
              width: `${2 + Math.random() * 2}px`,
              height: `${2 + Math.random() * 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.1 + Math.random() * 0.2,
              animation: `float ${4 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      {/* Scattered stars */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white"
            style={{
              width: `${1 + Math.random() * 2}px`,
              height: `${1 + Math.random() * 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.2 + Math.random() * 0.3,
              animation: `twinkle ${2 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-[700px] mx-auto px-6">
        <h2
          className="font-display italic text-golden text-center mb-16"
          style={{ fontSize: 'clamp(1.5rem, 3vw, 2rem)' }}
        >
          A Letter I Should Have Written Long Ago
        </h2>

        <div
          className="relative p-8 md:p-12 rounded-2xl"
          style={{
            background: 'rgba(13, 27, 42, 0.6)',
            backgroundImage:
              'radial-gradient(ellipse at top left, rgba(212, 168, 83, 0.08) 0%, transparent 50%)',
          }}
        >
          {/* Letter content */}
          <div
            className="font-letter text-warm-cream leading-[2] whitespace-pre-wrap"
            style={{ fontSize: 'clamp(1.25rem, 2vw, 1.6rem)' }}
          >
            {displayedText}
            {!isComplete && (
              <span
                className="inline-block w-0.5 h-6 bg-golden ml-1 align-middle"
                style={{ animation: 'caret-blink 1s step-end infinite' }}
              />
            )}
          </div>

          {/* Signature */}
          <div
            className={`mt-8 transition-opacity duration-1000 ${
              isComplete ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <p className="font-display italic text-golden text-xl md:text-2xl">
              — Your Son
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
