import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const qualities = [
  {
    name: 'Protector',
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" stroke="#D4A853" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M24 4L8 12V22C8 32 14.5 40.5 24 44C33.5 40.5 40 32 40 22V12L24 4Z" />
        <path d="M18 22L22 26L30 18" />
      </svg>
    ),
  },
  {
    name: 'Teacher',
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" stroke="#D4A853" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M8 36V12L24 6L40 12V36" />
        <path d="M8 12L24 18L40 12" />
        <line x1="24" y1="18" x2="24" y2="42" />
        <path d="M16 38C16 38 20 42 24 42C28 42 32 38 32 38" />
        <line x1="18" y1="22" x2="18" y2="32" />
        <line x1="30" y1="22" x2="30" y2="32" />
      </svg>
    ),
  },
  {
    name: 'Guide',
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" stroke="#D4A853" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="24" cy="24" r="18" />
        <path d="M24 10V24L32 32" />
        <circle cx="24" cy="24" r="2" fill="#D4A853" />
      </svg>
    ),
  },
  {
    name: 'Best Friend',
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" stroke="#D4A853" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 20C14 20 10 22 10 26C10 30 14 32 14 32" />
        <path d="M34 20C34 20 38 22 38 26C38 30 34 32 34 32" />
        <ellipse cx="18" cy="26" rx="6" ry="8" />
        <ellipse cx="30" cy="26" rx="6" ry="8" />
        <path d="M24 34C24 34 22 36 24 38C26 36 24 34 24 34Z" fill="#D4A853" />
      </svg>
    ),
  },
  {
    name: 'Inspiration',
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" stroke="#D4A853" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="24" cy="24" r="8" />
        <line x1="24" y1="6" x2="24" y2="12" />
        <line x1="24" y1="36" x2="24" y2="42" />
        <line x1="6" y1="24" x2="12" y2="24" />
        <line x1="36" y1="24" x2="42" y2="24" />
        <line x1="11.3" y1="11.3" x2="15.5" y2="15.5" />
        <line x1="32.5" y1="32.5" x2="36.7" y2="36.7" />
        <line x1="11.3" y1="36.7" x2="15.5" y2="32.5" />
        <line x1="32.5" y1="15.5" x2="36.7" y2="11.3" />
      </svg>
    ),
  },
];

export default function Qualities() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      if (prefersReducedMotion) {
        gsap.set(el.querySelectorAll('.quality-card'), { opacity: 1, y: 0, scale: 1 });
        return;
      }

      gsap.from(el.querySelectorAll('.quality-card'), {
        opacity: 0,
        y: 50,
        scale: 0.95,
        duration: 0.7,
        stagger: 0.12,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 75%',
          toggleActions: 'play none none none',
        },
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-[clamp(80px,12vh,140px)] bg-midnight"
      aria-label="What you are to me"
    >
      <div className="max-w-[1200px] mx-auto px-6">
        <h2
          className="font-display text-white text-center mb-4"
          style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}
        >
          What You Are to Me
        </h2>
        <p className="font-body font-light text-light-slate text-center mb-16 tracking-wide">
          Five words that will never be enough.
        </p>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {qualities.map((quality, i) => (
            <div
              key={i}
              className="quality-card glass-card p-8 flex flex-col items-center text-center transition-all duration-500 hover:-translate-y-2 hover:border-golden/40 hover:shadow-golden-glow cursor-default group"
            >
              <div className="transition-transform duration-300 group-hover:scale-110">
                {quality.icon}
              </div>
              <h3 className="font-display text-warm-cream text-lg mt-6">
                {quality.name}
              </h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
