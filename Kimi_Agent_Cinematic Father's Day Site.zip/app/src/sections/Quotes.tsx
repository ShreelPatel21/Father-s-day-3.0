import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const quotes = [
  'A father is neither an anchor to hold us back, nor a sail to take us there, but the wind that fills our wings.',
  'The greatest mark of a father is how he treats his children when no one is looking.',
  'My father gave me the greatest gift anyone could give another person: he believed in me.',
  'A good father is one of the most unsung, unpraised, unnoticed, and yet one of the most valuable assets in our society.',
  'When you teach your son, you teach your son\'s son.',
];

export default function Quotes() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      if (prefersReducedMotion) {
        gsap.set(el.querySelectorAll('.quote-item'), { opacity: 1, y: 0 });
        return;
      }

      el.querySelectorAll('.quote-item').forEach((quote) => {
        gsap.from(quote, {
          opacity: 0,
          y: 30,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: quote,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        });
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-[clamp(80px,12vh,140px)] bg-midnight"
      aria-label="Words that describe you"
    >
      {/* Star background - denser */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 100 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              width: `${1 + Math.random() * 2}px`,
              height: `${1 + Math.random() * 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              background: Math.random() > 0.5 ? '#F5E6C8' : '#fff',
              opacity: 0.2 + Math.random() * 0.4,
              animation: `twinkle ${2 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-[1200px] mx-auto px-6">
        <h2
          className="font-display italic text-golden text-center mb-20"
          style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}
        >
          Words That Describe You
        </h2>

        <div className="space-y-16">
          {quotes.map((quote, i) => (
            <div key={i} className="quote-item max-w-[700px] mx-auto text-center">
              <span
                className="font-display text-golden block mb-4"
                style={{ fontSize: '3rem', lineHeight: 0.5 }}
              >
                &ldquo;
              </span>
              <p
                className="font-display italic text-warm-cream leading-[1.6]"
                style={{ fontSize: 'clamp(1.25rem, 2.5vw, 1.8rem)' }}
              >
                {quote}
              </p>
              <span
                className="font-display text-golden block mt-4"
                style={{ fontSize: '3rem', lineHeight: 0.5 }}
              >
                &rdquo;
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
