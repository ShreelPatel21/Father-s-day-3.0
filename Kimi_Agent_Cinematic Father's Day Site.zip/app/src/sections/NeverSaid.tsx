import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const statements = [
  { text: 'Dad, I know I don\'t talk much.', size: '1.5rem' },
  { text: 'I know I don\'t always listen.', size: '1.5rem' },
  { text: 'I know I spend more time in my room than with you.', size: '1.5rem' },
  { text: 'But every lesson you taught me lives inside me.', size: '2rem' },
  { text: 'And I am becoming the man you always believed I could be.', size: '2.5rem' },
];

export default function NeverSaid() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      // Heading blur-in effect
      if (headingRef.current && !prefersReducedMotion) {
        const observer = new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                headingRef.current?.classList.add('animate');
                observer.disconnect();
              }
            });
          },
          { threshold: 0.5 }
        );
        observer.observe(headingRef.current);
      }

      // Statement reveals with dimming
      const statementEls = el.querySelectorAll('.never-said-statement');

      statementEls.forEach((stmt, i) => {
        if (prefersReducedMotion) {
          gsap.set(stmt, { opacity: 1, y: 0 });
          return;
        }

        // Fade in
        gsap.from(stmt, {
          opacity: 0,
          y: 40,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: stmt,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        });

        // Dim previous statement when next one comes in
        if (i > 0) {
          gsap.to(statementEls[i - 1], {
            opacity: 0.15,
            scrollTrigger: {
              trigger: stmt,
              start: 'top 75%',
              toggleActions: 'play none none reverse',
            },
          });
        }
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full min-h-screen flex flex-col items-center justify-center py-[clamp(80px,12vh,140px)]"
      style={{ background: '#060A12' }}
      aria-label="The things I never said"
    >
      {/* Vignette */}
      <div className="absolute inset-0 vignette pointer-events-none" />

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-golden"
            style={{
              width: `${2 + Math.random() * 3}px`,
              height: `${2 + Math.random() * 3}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.1 + Math.random() * 0.3,
              animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-[900px] mx-auto px-6 text-center">
        <h2
          ref={headingRef}
          className="blur-text font-display text-golden mb-20"
          data-text="The Things I Never Said"
          style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
        >
          The Things I Never Said
        </h2>

        <div className="space-y-20">
          {statements.map((stmt, i) => (
            <p
              key={i}
              className="never-said-statement font-display italic text-warm-cream leading-[1.5]"
              style={{ fontSize: `clamp(1.25rem, 3vw, ${stmt.size})` }}
            >
              {stmt.text}
            </p>
          ))}
        </div>
      </div>
    </section>
  );
}
