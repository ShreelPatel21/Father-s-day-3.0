import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const lines = [
  { text: 'I spent years trying to become successful.', color: '#F5E6C8' },
  { text: 'But now I understand...', color: '#F5E6C8' },
  { text: 'My greatest achievement...', color: '#F5E6C8' },
  { text: 'Is being your son.', color: '#D4A853' },
];

export default function Sunrise() {
  const sectionRef = useRef<HTMLElement>(null);
  const [visibleLines, setVisibleLines] = useState(0);
  const [showTitle, setShowTitle] = useState(false);
  const heartsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: el,
        start: 'top 50%',
        onEnter: () => {
          if (prefersReducedMotion) {
            setVisibleLines(lines.length);
            setShowTitle(true);
            return;
          }

          // Reveal lines sequentially
          lines.forEach((_, i) => {
            setTimeout(() => {
              setVisibleLines(i + 1);
            }, i * 800);
          });

          // Show title card after lines
          setTimeout(() => {
            setShowTitle(true);
          }, lines.length * 800 + 1000);
        },
        once: true,
      });

      // Pin the section during text reveal
      if (!prefersReducedMotion) {
        ScrollTrigger.create({
          trigger: el,
          start: 'top top',
          end: '+=150%',
          pin: true,
          pinSpacing: true,
        });
      }
    }, el);

    return () => ctx.revert();
  }, []);

  // Generate floating hearts
  useEffect(() => {
    if (!showTitle || !heartsRef.current) return;

    const container = heartsRef.current;
    const heartCount = 15;

    for (let i = 0; i < heartCount; i++) {
      const heart = document.createElement('div');
      heart.innerHTML = '&#9829;';
      heart.style.cssText = `
        position: absolute;
        color: #D4A853;
        font-size: ${12 + Math.random() * 8}px;
        opacity: ${0.3 + Math.random() * 0.3};
        left: ${Math.random() * 100}%;
        bottom: -30px;
        pointer-events: none;
        animation: heart-float ${8 + Math.random() * 7}s linear infinite;
        animation-delay: ${Math.random() * 10}s;
      `;
      container.appendChild(heart);
    }

    return () => {
      container.innerHTML = '';
    };
  }, [showTitle]);

  return (
    <section
      ref={sectionRef}
      className="relative w-full min-h-screen flex flex-col items-center justify-center overflow-hidden"
      style={{
        background: 'linear-gradient(to top, #0B0F1A 0%, #1A1F3A 25%, #3D2B5A 50%, #8B5E3C 75%, #D4A853 100%)',
      }}
      aria-label="The sunrise"
    >
      {/* Floating hearts container */}
      <div ref={heartsRef} className="absolute inset-0 overflow-hidden pointer-events-none z-[2]" />

      {/* Sunrise silhouette */}
      <div className="absolute bottom-0 left-0 right-0 z-[1]">
        <img
          src="/images/sunrise-silhouette.jpg"
          alt="Father and son walking together toward the sunrise"
          className="w-full h-auto object-cover opacity-60"
          style={{ maxHeight: '50vh', maskImage: 'linear-gradient(to top, black 50%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to top, black 50%, transparent 100%)' }}
        />
      </div>

      <div className="relative z-[3] max-w-[900px] mx-auto px-6 text-center">
        {/* Son's final words */}
        <div className="space-y-4 mb-16">
          {lines.map((line, i) => (
            <p
              key={i}
              className="font-display italic transition-all duration-1000"
              style={{
                fontSize: 'clamp(1.25rem, 2.5vw, 1.8rem)',
                lineHeight: 1.8,
                color: line.color,
                opacity: visibleLines > i ? 1 : 0,
                transform: visibleLines > i ? 'translateY(0)' : 'translateY(20px)',
              }}
            >
              {line.text}
            </p>
          ))}
        </div>

        {/* Title card */}
        <div
          className={`transition-all duration-1200 ${
            showTitle ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h2
            className="font-display font-bold text-white tracking-wide"
            style={{
              fontSize: 'clamp(2rem, 5vw, 3.5rem)',
              letterSpacing: '0.05em',
              textShadow: '0 0 40px rgba(212, 168, 83, 0.3)',
            }}
          >
            HAPPY FATHER'S DAY 2026
          </h2>

          <p className="font-body font-light text-warm-cream mt-6">
            To the man who gave me everything... even when I never asked.
          </p>

          <span
            className="text-golden text-2xl block mt-8"
            style={{ animation: 'pulse-glow 2s ease-in-out infinite' }}
          >
            &#10022;
          </span>
        </div>
      </div>
    </section>
  );
}
