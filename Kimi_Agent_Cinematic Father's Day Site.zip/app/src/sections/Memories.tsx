import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const memories = [
  { img: '/images/memory-1.jpg', caption: 'You taught me to ride a bike. I taught you to let go.', rotation: -4 },
  { img: '/images/memory-2.jpg', caption: 'Sunday mornings. Your coffee. My cartoons.', rotation: 3 },
  { img: '/images/memory-3.jpg', caption: 'The day you told me failure is just a lesson in disguise.', rotation: -2 },
  { img: '/images/memory-4.jpg', caption: 'Birthdays where you made me feel like the only child in the world.', rotation: 5 },
  { img: '/images/memory-5.jpg', caption: 'The way you looked at me when you thought I never noticed.', rotation: -3 },
  { img: '/images/memory-6.jpg', caption: 'Every small sacrifice you thought I never saw.', rotation: 2 },
];

export default function Memories() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      if (prefersReducedMotion) {
        gsap.set(el.querySelectorAll('.memory-card'), { opacity: 1, y: 0 });
        return;
      }

      gsap.from(el.querySelectorAll('.memory-card'), {
        opacity: 0,
        y: 60,
        duration: 0.7,
        stagger: 0.15,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 75%',
          toggleActions: 'play none none none',
        },
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="memories"
      ref={sectionRef}
      className="relative w-full py-[clamp(80px,12vh,140px)] bg-midnight overflow-hidden"
      aria-label="Memories"
    >
      {/* Star background */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 80 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white"
            style={{
              width: `${2 + Math.random() * 2}px`,
              height: `${2 + Math.random() * 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.2 + Math.random() * 0.4,
              animation: `twinkle ${2 + Math.random() * 2}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-[1200px] mx-auto px-6">
        <h2
          className="font-display italic text-golden text-center mb-4"
          style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}
        >
          Memories That Made Me
        </h2>
        <p className="font-body font-light text-light-slate text-center mb-16 tracking-wide">
          Every photo holds a thousand unspoken thank yous.
        </p>

        <div className="flex flex-wrap justify-center gap-6 md:gap-8">
          {memories.map((memory, i) => (
            <div
              key={i}
              className="memory-card polaroid cursor-pointer"
              style={{
                transform: `rotate(${memory.rotation}deg)`,
                animation: `float ${3 + Math.random() * 2}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 2}s`,
                maxWidth: '280px',
                width: '100%',
              }}
            >
              <div className="overflow-hidden rounded-lg" style={{ aspectRatio: '4/3' }}>
                <img
                  src={memory.img}
                  alt={memory.caption}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
              <p className="font-letter text-dark-navy text-center mt-4 leading-snug" style={{ fontSize: '1rem' }}>
                {memory.caption}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
