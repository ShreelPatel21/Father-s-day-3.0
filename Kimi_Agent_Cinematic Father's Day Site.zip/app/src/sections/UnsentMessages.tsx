import { useEffect, useRef, useState, useCallback } from 'react';

const messages = [
  'Thank you, Dad.',
  'I\'m proud to be your son.',
  'You mean everything to me.',
];

const finalMessage = 'I love you, Dad.';

export default function UnsentMessages() {
  const sectionRef = useRef<HTMLElement>(null);
  const [displayedText, setDisplayedText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [phase, setPhase] = useState<'typing' | 'holding' | 'deleting' | 'final' | 'done'>('typing');
  const [isVisible, setIsVisible] = useState(false);
  const [showCaption, setShowCaption] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hasStartedRef = useRef(false);

  const clearIntervalSafe = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  // Observe visibility
  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasStartedRef.current) {
            setIsVisible(true);
            hasStartedRef.current = true;
          }
        });
      },
      { threshold: 0.5 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Typewriter sequence
  useEffect(() => {
    if (!isVisible) return;

    const currentMsg = currentIndex < messages.length ? messages[currentIndex] : finalMessage;
    let charIndex = 0;

    if (phase === 'typing') {
      charIndex = 0;
      setDisplayedText('');
      intervalRef.current = setInterval(() => {
        if (charIndex < currentMsg.length) {
          setDisplayedText(currentMsg.slice(0, charIndex + 1));
          charIndex++;
        } else {
          clearIntervalSafe();
          if (currentIndex < messages.length) {
            setPhase('holding');
          } else {
            setPhase('done');
            setTimeout(() => setShowCaption(true), 1000);
          }
        }
      }, 60);
    }

    if (phase === 'holding') {
      intervalRef.current = setTimeout(() => {
        setPhase('deleting');
      }, 2000) as unknown as ReturnType<typeof setInterval>;
    }

    if (phase === 'deleting') {
      charIndex = displayedText.length;
      intervalRef.current = setInterval(() => {
        if (charIndex > 0) {
          setDisplayedText(displayedText.slice(0, charIndex - 1));
          charIndex--;
        } else {
          clearIntervalSafe();
          setCurrentIndex((prev) => prev + 1);
          setPhase('typing');
        }
      }, 20);
    }

    if (phase === 'done') {
      setDisplayedText(finalMessage);
    }

    return () => clearIntervalSafe();
  }, [isVisible, phase, currentIndex, clearIntervalSafe]);

  const isFinal = phase === 'done';

  return (
    <section
      ref={sectionRef}
      className="relative w-full min-h-screen flex flex-col items-center justify-center py-[clamp(80px,12vh,140px)]"
      style={{ background: '#060A12' }}
      aria-label="Unsent messages"
    >
      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 40 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-golden"
            style={{
              width: `${2 + Math.random() * 3}px`,
              height: `${2 + Math.random() * 3}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.1 + Math.random() * 0.25,
              animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      {/* Star background */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 50 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white"
            style={{
              width: `${1 + Math.random() * 2}px`,
              height: `${1 + Math.random() * 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.15 + Math.random() * 0.3,
              animation: `twinkle ${2 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <div
        className={`relative z-10 transition-opacity duration-500 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {/* Phone mockup container */}
        <div
          className="glass-card-enhanced p-12 md:p-16 max-w-[500px] w-[90vw]"
          style={{ borderRadius: '24px' }}
        >
          {/* Cursor + text */}
          <div className="flex items-start gap-1">
            <span
              className={`font-display text-warm-cream whitespace-pre-wrap leading-relaxed ${
                isFinal ? 'text-golden' : ''
              }`}
              style={{
                fontSize: 'clamp(1.5rem, 3vw, 2.5rem)',
                textShadow: isFinal ? '0 0 30px rgba(212, 168, 83, 0.4)' : 'none',
                animation: isFinal ? 'pulse-glow 2s ease-in-out infinite' : 'none',
              }}
            >
              {displayedText}
            </span>
            <span
              className="w-0.5 h-8 bg-golden ml-1"
              style={{
                animation: 'caret-blink 1s step-end infinite',
              }}
            />
          </div>
        </div>

        {/* Caption */}
        <p
          className={`font-body font-light text-muted-slate text-center mt-8 transition-opacity duration-1000 ${
            showCaption ? 'opacity-100' : 'opacity-0'
          }`}
        >
          Finally, the words I should have said a thousand times.
        </p>
      </div>
    </section>
  );
}
