import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const lines = [
  'I was never good at saying how much you mean to me...',
  'But every step I take carries the lessons you taught me.',
  'This is my letter to the man I call Dad.',
];

export default function OpeningScene() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      gsap.set(el.querySelectorAll('.opening-line'), { opacity: 1, y: 0 });
      return;
    }

    const ctx = gsap.context(() => {
      gsap.from(el.querySelectorAll('.opening-line'), {
        opacity: 0,
        y: 30,
        duration: 0.8,
        stagger: 0.6,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 75%',
          toggleActions: 'play none none none',
        },
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-[clamp(80px,12vh,140px)]"
      style={{
        background: 'linear-gradient(to bottom, #0B0F1A 0%, #0D1320 100%)',
      }}
      aria-label="Opening words"
    >
      {/* Subtle floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 15 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-golden"
            style={{
              width: `${2 + Math.random() * 3}px`,
              height: `${2 + Math.random() * 3}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.15 + Math.random() * 0.25,
              animation: `float ${3 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-[700px] mx-auto px-6 text-center">
        {lines.map((line, i) => (
          <p
            key={i}
            className="opening-line font-display italic text-warm-cream leading-[1.6] mb-8 last:mb-0"
            style={{ fontSize: 'clamp(1.5rem, 3vw, 2.25rem)' }}
          >
            {line}
          </p>
        ))}
      </div>
    </section>
  );
}
