import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const reflections = [
  {
    before: 'At seventeen, I thought you were strict.',
    after: 'Now I realize you were protecting me.',
  },
  {
    before: 'At seventeen, I thought you worried too much.',
    after: 'Now I realize that was love.',
  },
  {
    before: 'At seventeen, I thought you didn\'t understand me.',
    after: 'Now I realize you understood me better than anyone.',
  },
  {
    before: 'At seventeen, I couldn\'t wait to leave.',
    after: 'Now I can\'t imagine a world without you in it.',
  },
];

export default function AtSeventeen() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      if (prefersReducedMotion) {
        gsap.set(el.querySelectorAll('.seventeen-text'), { opacity: 1, y: 0 });
        gsap.set(el.querySelector('.seventeen-image'), { opacity: 1, scale: 1 });
        return;
      }

      gsap.from(el.querySelectorAll('.seventeen-text'), {
        opacity: 0,
        y: 30,
        duration: 0.7,
        stagger: 0.15,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 70%',
          toggleActions: 'play none none none',
        },
      });

      gsap.from(el.querySelector('.seventeen-image'), {
        opacity: 0,
        scale: 0.95,
        duration: 0.8,
        delay: 0.2,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 70%',
          toggleActions: 'play none none none',
        },
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-[clamp(80px,12vh,140px)] bg-midnight"
      aria-label="At seventeen"
    >
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 md:gap-16 items-center">
          {/* Left: Text */}
          <div>
            <p className="seventeen-text font-body font-medium text-golden uppercase tracking-[0.15em] text-sm mb-4">
              Age Seventeen
            </p>
            <h2
              className="seventeen-text font-display text-white mb-12"
              style={{ fontSize: 'clamp(1.75rem, 3vw, 2.5rem)' }}
            >
              The Years I Took for Granted
            </h2>

            <div className="space-y-8">
              {reflections.map((ref, i) => (
                <div key={i} className="seventeen-text flex gap-4">
                  <div
                    className="flex-shrink-0 w-0.5 mt-1"
                    style={{
                      background: 'linear-gradient(to bottom, #D4A853, transparent)',
                      height: '40px',
                    }}
                  />
                  <p className="font-body font-light text-light-slate leading-[1.8]">
                    {ref.before}{' '}
                    <span className="text-warm-cream">{ref.after}</span>
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Image */}
          <div className="seventeen-image relative">
            <div
              className="rounded-xl overflow-hidden"
              style={{
                boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5), 0 0 40px rgba(212, 168, 83, 0.1)',
              }}
            >
              <img
                src="/images/seventeen-scene.jpg"
                alt="A teenage boy studying late at night while his father watches from the doorway"
                className="w-full h-auto object-cover"
                loading="lazy"
                style={{ aspectRatio: '4/3' }}
              />
            </div>
            {/* Vignette overlay */}
            <div
              className="absolute inset-0 rounded-xl pointer-events-none"
              style={{
                boxShadow: 'inset 0 0 60px rgba(11, 15, 26, 0.5)',
              }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
