import { useCallback, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import useLenis from './hooks/useLenis';
import Navigation from './components/Navigation';
import CursorTrail from './components/CursorTrail';
import MusicControl from './components/MusicControl';
import Hero from './sections/Hero';
import OpeningScene from './sections/OpeningScene';
import Journey from './sections/Journey';
import Memories from './sections/Memories';
import NeverSaid from './sections/NeverSaid';
import FatherNeverSaid from './sections/FatherNeverSaid';
import AtSeventeen from './sections/AtSeventeen';
import UnsentMessages from './sections/UnsentMessages';
import Letter from './sections/Letter';
import Qualities from './sections/Qualities';
import Quotes from './sections/Quotes';
import Wish from './sections/Wish';
import Climax from './sections/Climax';
import Sunrise from './sections/Sunrise';

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const lenisRef = useLenis();

  const handleNavigate = useCallback(
    (id: string) => {
      const el = document.getElementById(id);
      if (el && lenisRef.current) {
        lenisRef.current.scrollTo(el, { offset: -64 });
      }
    },
    [lenisRef]
  );

  useEffect(() => {
    // Refresh ScrollTrigger after everything loads
    const timer = setTimeout(() => {
      ScrollTrigger.refresh();
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative bg-midnight min-h-screen">
      <Navigation onNavigate={handleNavigate} />
      <CursorTrail />
      <MusicControl />

      <main>
        <Hero />
        <OpeningScene />
        <Journey />
        <Memories />
        <NeverSaid />
        <FatherNeverSaid />
        <AtSeventeen />
        <UnsentMessages />
        <Letter />
        <Qualities />
        <Quotes />
        <Wish />
        <Climax />
        <Sunrise />
      </main>

      {/* Footer */}
      <footer className="w-full py-8 bg-midnight text-center">
        <p className="font-body font-light text-muted-slate text-sm">
          Made with love for Father's Day 2026
        </p>
      </footer>
    </div>
  );
}
