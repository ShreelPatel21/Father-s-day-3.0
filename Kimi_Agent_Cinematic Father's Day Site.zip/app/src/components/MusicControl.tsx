import { useState, useRef, useEffect } from 'react';

export default function MusicControl() {
  const [playing, setPlaying] = useState(false);
  const [visible, setVisible] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > window.innerHeight * 0.5);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Pulse the button once when user reaches letter section
  useEffect(() => {
    const handleScroll = () => {
      const letterSection = document.getElementById('letter');
      if (letterSection && !playing) {
        const rect = letterSection.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          // Could trigger a pulse here
        }
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [playing]);

  const toggleMusic = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio('/music/fathers-day-piano.mp3');
      audioRef.current.loop = true;
      audioRef.current.volume = 0.3;
    }

    if (playing) {
      audioRef.current.pause();
      setPlaying(false);
    } else {
      audioRef.current.play().catch(() => {});
      setPlaying(true);
    }
  };

  return (
    <button
      onClick={toggleMusic}
      className={`fixed bottom-8 right-8 z-50 w-12 h-12 rounded-full glass-card flex items-center justify-center transition-all duration-500 hover:scale-110 hover:border-golden/40 hover:shadow-golden-glow ${
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
      }`}
      aria-label={playing ? 'Pause music' : 'Play music'}
    >
      {playing ? (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <rect x="3" y="2" width="4" height="12" rx="1" fill="#D4A853" />
          <rect x="9" y="2" width="4" height="12" rx="1" fill="#D4A853" />
        </svg>
      ) : (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path d="M4 2L14 8L4 14V2Z" fill="#D4A853" />
        </svg>
      )}

      {/* Soundwave animation */}
      {playing && (
        <>
          <span className="absolute w-3 h-3 rounded-full border border-golden/40 animate-ping" style={{ animationDuration: '1.5s' }} />
          <span
            className="absolute -inset-1 rounded-full border border-golden/20"
            style={{ animation: 'soundwave 2s ease-in-out infinite' }}
          />
        </>
      )}
    </button>
  );
}
