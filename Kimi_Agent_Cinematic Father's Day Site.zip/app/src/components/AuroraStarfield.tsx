import { useRef, useEffect } from 'react';

interface AuroraStarfieldProps {
  starCount?: number;
  particleCount?: number;
  auroraOpacity?: number;
  className?: string;
}

interface Star {
  x: number;
  y: number;
  baseRadius: number;
  alpha: number;
  twinkleSpeed: number;
  twinklePhase: number;
}

interface Particle {
  x: number;
  y: number;
  radius: number;
  speedY: number;
  speedX: number;
  alpha: number;
  color: string;
}

interface AuroraLayer {
  yBase: number;
  amplitude: number;
  frequency: number;
  speed: number;
  alpha: number;
  gradientColors: [string, string];
  phase: number;
}

export default function AuroraStarfield({
  starCount = 400,
  particleCount = 50,
  auroraOpacity = 1,
  className = '',
}: AuroraStarfieldProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: -1000, y: -1000 });
  const animRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let stars: Star[] = [];
    let particles: Particle[] = [];
    let auroraLayers: AuroraLayer[] = [];

    const isLowPower = (navigator.hardwareConcurrency || 4) < 4;
    const actualStarCount = isLowPower ? Math.floor(starCount / 2) : starCount;
    const actualParticleCount = isLowPower ? Math.floor(particleCount / 2) : particleCount;

    function init() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = canvas!.parentElement?.clientWidth || window.innerWidth;
      height = canvas!.parentElement?.clientHeight || window.innerHeight;
      canvas!.width = width * dpr;
      canvas!.height = height * dpr;
      ctx!.scale(dpr, dpr);

      // Init stars
      stars = [];
      for (let i = 0; i < actualStarCount; i++) {
        stars.push({
          x: Math.random() * width,
          y: Math.random() * height,
          baseRadius: 0.5 + Math.random() * 1.5,
          alpha: 0.2 + Math.random() * 0.7,
          twinkleSpeed: 0.005 + Math.random() * 0.015,
          twinklePhase: Math.random() * Math.PI * 2,
        });
      }

      // Init particles
      const particleColors = ['#D4A853', '#C9A96E', '#E8D5A3', '#F5E6C8'];
      particles = [];
      for (let i = 0; i < actualParticleCount; i++) {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          radius: 1 + Math.random() * 2,
          speedY: -(0.2 + Math.random() * 0.6),
          speedX: -0.1 + Math.random() * 0.2,
          alpha: 0.1 + Math.random() * 0.4,
          color: particleColors[Math.floor(Math.random() * particleColors.length)],
        });
      }

      // Init aurora layers
      auroraLayers = [
        {
          yBase: height * 0.15,
          amplitude: 60,
          frequency: 0.002,
          speed: 0.001,
          alpha: 0.12 * auroraOpacity,
          gradientColors: ['#1B5E20', '#D4A853'],
          phase: 0,
        },
        {
          yBase: height * 0.2,
          amplitude: 80,
          frequency: 0.0015,
          speed: 0.0008,
          alpha: 0.1 * auroraOpacity,
          gradientColors: ['#2E7D32', '#C9A96E'],
          phase: Math.PI,
        },
        {
          yBase: height * 0.25,
          amplitude: 50,
          frequency: 0.0025,
          speed: 0.0012,
          alpha: 0.08 * auroraOpacity,
          gradientColors: ['#4CAF50', '#E8D5A3'],
          phase: Math.PI * 0.5,
        },
      ];
    }

    function drawSky() {
      const gradient = ctx!.createLinearGradient(0, 0, 0, height);
      gradient.addColorStop(0, '#0B0F1A');
      gradient.addColorStop(0.5, '#0D1B2A');
      gradient.addColorStop(1, '#16263B');
      ctx!.fillStyle = gradient;
      ctx!.fillRect(0, 0, width, height);
    }

    function drawAurora() {
      for (const layer of auroraLayers) {
        layer.phase += layer.speed;

        const grad = ctx!.createLinearGradient(0, layer.yBase - 80, 0, layer.yBase + 80);
        grad.addColorStop(0, hexToRgba(layer.gradientColors[0], 0));
        grad.addColorStop(0.3, hexToRgba(layer.gradientColors[0], layer.alpha));
        grad.addColorStop(0.7, hexToRgba(layer.gradientColors[1], layer.alpha * 0.6));
        grad.addColorStop(1, hexToRgba(layer.gradientColors[1], 0));

        ctx!.fillStyle = grad;
        ctx!.beginPath();
        ctx!.moveTo(0, layer.yBase + Math.sin(layer.phase) * layer.amplitude);

        for (let x = 0; x <= width; x += 5) {
          const y = layer.yBase + Math.sin(x * layer.frequency + layer.phase) * layer.amplitude;
          ctx!.lineTo(x, y);
        }

        ctx!.lineTo(width, height);
        ctx!.lineTo(0, height);
        ctx!.closePath();
        ctx!.fill();
      }
    }

    function drawStars() {
      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;

      for (const star of stars) {
        star.twinklePhase += star.twinkleSpeed;
        let currentAlpha = star.alpha * (0.6 + 0.4 * Math.sin(star.twinklePhase));

        // Mouse interaction
        const dx = star.x - mx;
        const dy = star.y - my;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 150) {
          const force = (150 - dist) / 150;
          star.x += (dx / dist) * force * 2;
          star.y += (dy / dist) * force * 2;
          currentAlpha = Math.min(1, currentAlpha + 0.3);
        }

        ctx!.beginPath();
        ctx!.arc(star.x, star.y, star.baseRadius, 0, Math.PI * 2);
        ctx!.fillStyle = `rgba(240, 242, 245, ${currentAlpha})`;
        ctx!.fill();

        // Wrap stars that were pushed off screen
        if (star.x < 0) star.x = width;
        if (star.x > width) star.x = 0;
        if (star.y < 0) star.y = height;
        if (star.y > height) star.y = 0;
      }
    }

    function drawParticles() {
      for (const p of particles) {
        p.y += p.speedY;
        p.x += p.speedX;

        if (p.y < -10) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;

        ctx!.beginPath();
        ctx!.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx!.fillStyle = p.color;
        ctx!.globalAlpha = p.alpha;
        ctx!.fill();
        ctx!.globalAlpha = 1;
      }
    }

    function hexToRgba(hex: string, alpha: number): string {
      const r = parseInt(hex.slice(1, 3), 16);
      const g = parseInt(hex.slice(3, 5), 16);
      const b = parseInt(hex.slice(5, 7), 16);
      return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    function animate() {
      drawSky();
      drawAurora();
      drawStars();
      drawParticles();
      animRef.current = requestAnimationFrame(animate);
    }

    function handleMouseMove(e: MouseEvent) {
      const rect = canvas!.getBoundingClientRect();
      mouseRef.current.x = e.clientX - rect.left;
      mouseRef.current.y = e.clientY - rect.top;
    }

    function handleResize() {
      init();
    }

    init();
    animate();

    canvas.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animRef.current);
      canvas.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
    };
  }, [starCount, particleCount, auroraOpacity]);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'auto' }}
    />
  );
}
