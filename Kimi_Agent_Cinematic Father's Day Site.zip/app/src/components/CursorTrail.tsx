import { useRef, useEffect } from 'react';

export default function CursorTrail() {
  const trailRef = useRef<HTMLDivElement>(null);
  const posRef = useRef({ x: 0, y: 0 });
  const targetRef = useRef({ x: 0, y: 0 });
  const animRef = useRef<number>(0);

  useEffect(() => {
    // Disable on touch devices
    if ('ontouchstart' in window) return;

    const trail = trailRef.current;
    if (!trail) return;

    function handleMouseMove(e: MouseEvent) {
      targetRef.current.x = e.clientX;
      targetRef.current.y = e.clientY;
    }

    function animate() {
      posRef.current.x += (targetRef.current.x - posRef.current.x) * 0.1;
      posRef.current.y += (targetRef.current.y - posRef.current.y) * 0.1;

      if (trail) {
        trail.style.transform = `translate(${posRef.current.x - 4}px, ${posRef.current.y - 4}px)`;
      }

      animRef.current = requestAnimationFrame(animate);
    }

    window.addEventListener('mousemove', handleMouseMove);
    animRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animRef.current);
    };
  }, []);

  // Don't render on touch devices
  if (typeof window !== 'undefined' && 'ontouchstart' in window) {
    return null;
  }

  return (
    <div
      ref={trailRef}
      className="fixed top-0 left-0 w-2 h-2 rounded-full pointer-events-none z-[9999]"
      style={{
        background: 'radial-gradient(circle, rgba(212,168,83,0.5) 0%, rgba(212,168,83,0) 70%)',
        boxShadow: '0 0 12px rgba(212,168,83,0.3)',
      }}
    />
  );
}
