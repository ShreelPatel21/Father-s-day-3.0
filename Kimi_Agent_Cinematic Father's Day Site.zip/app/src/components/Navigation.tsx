import { useState, useEffect } from 'react';

interface NavigationProps {
  onNavigate: (id: string) => void;
}

const navLinks = [
  { label: 'Journey', id: 'journey' },
  { label: 'Memories', id: 'memories' },
  { label: 'Letter', id: 'letter' },
  { label: 'Wishes', id: 'wishes' },
];

export default function Navigation({ onNavigate }: NavigationProps) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 h-16 flex items-center justify-between transition-all duration-500 ${
          scrolled
            ? 'bg-[rgba(11,15,26,0.9)] backdrop-blur-xl'
            : 'bg-transparent'
        }`}
        style={{ padding: '0 clamp(1.5rem, 4vw, 3rem)' }}
      >
        <button
          onClick={() => onNavigate('hero')}
          className="font-display text-lg text-golden tracking-wide hover:opacity-80 transition-opacity"
        >
          Father & Son
        </button>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => onNavigate(link.id)}
              className="font-body text-sm font-medium text-white uppercase tracking-widest hover:text-golden transition-colors duration-300"
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden flex flex-col gap-1.5"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <span
            className={`block w-6 h-0.5 bg-golden transition-all duration-300 ${
              menuOpen ? 'rotate-45 translate-y-2' : ''
            }`}
          />
          <span
            className={`block w-6 h-0.5 bg-golden transition-all duration-300 ${
              menuOpen ? 'opacity-0' : ''
            }`}
          />
          <span
            className={`block w-6 h-0.5 bg-golden transition-all duration-300 ${
              menuOpen ? '-rotate-45 -translate-y-2' : ''
            }`}
          />
        </button>
      </nav>

      {/* Mobile menu overlay */}
      <div
        className={`fixed inset-0 z-40 bg-[rgba(11,15,26,0.98)] backdrop-blur-xl flex flex-col items-center justify-center gap-8 transition-all duration-500 md:hidden ${
          menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        {navLinks.map((link) => (
          <button
            key={link.id}
            onClick={() => {
              onNavigate(link.id);
              setMenuOpen(false);
            }}
            className="font-display text-2xl text-warm-cream hover:text-golden transition-colors duration-300"
          >
            {link.label}
          </button>
        ))}
      </div>
    </>
  );
}
